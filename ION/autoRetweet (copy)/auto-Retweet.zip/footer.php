<hr/>
<footer><center><div id="cc">&copy; برمجة <a href="http://parmagy.com" dir="ltr">parmagy.com</a></div></center></footer>
   