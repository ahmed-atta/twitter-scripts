<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
<title>Parmagy.com | المتابعات   </title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="author" content="parmagy.com">
<link href="./css/style.css" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="icons/favicon.png">
<link href="icons/favicon.ico" type="image/x-icon" rel="icon">
<!--[if lt IE 9]><script src="lib/html5shiv.js"></script><![endif]-->
<style type='text/css'>
	span.pages {
		border: 1px solid #0EB2CD;
		color: #FFFFFF;
		float: right;
		margin: 2px;
		padding: 5px 10px 6px;
		border-radius: 3px;
	}
</style>
</head>
<body>
